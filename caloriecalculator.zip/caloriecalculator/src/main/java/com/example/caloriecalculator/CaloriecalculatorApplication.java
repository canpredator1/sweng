package com.example.caloriecalculator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CaloriecalculatorApplication {

	public static void main(String[] args) {
		SpringApplication.run(CaloriecalculatorApplication.class, args);
	}

}
